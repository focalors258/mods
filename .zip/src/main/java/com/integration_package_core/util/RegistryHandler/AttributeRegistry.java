package com.integration_package_core.util.RegistryHandler;

public class AttributeRegistry {


    //public static final RegistryObject<Attribute> toughness = EntityBar.ATTRIBUTE.register("toughness", () -> new RangedAttribute("attribute.entity_bar.toughness", 0.0D, 0.0D, 1000D));








}
