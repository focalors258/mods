package com.integration_package_core.tool;

public interface EntityData {


    void setCrit(boolean crit);
}
