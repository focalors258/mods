package com.integration_package_core.mixinTool;

import software.bernie.geckolib.core.animation.RawAnimation;

public interface AnimationControllerMember {



    public void setCurrentRawAnimation(RawAnimation a);

    public void $stopTriggeredAnimation();

}
