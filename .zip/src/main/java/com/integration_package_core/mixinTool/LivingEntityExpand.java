package com.integration_package_core.mixinTool;

public interface LivingEntityExpand {

    //public float get

public void setIntData();


    public void setListData();


    public void setBooleanData();


    public void setDoubleData();

    public void setStringData();

    public void setData();














}
